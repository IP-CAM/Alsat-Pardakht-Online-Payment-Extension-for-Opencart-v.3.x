<?php

$_['text_wait'] = 'لطفا صبر کنید..';
$_['text_connect'] = 'در حال اتصال به درگاه آلسات پرداخت...';
$_['text_order_no'] = 'خرید شماره: ';
$_['button_view_cart'] = 'مشاهده سبد خرید';
$_['button_complete'] = 'تکمیل پرداخت';