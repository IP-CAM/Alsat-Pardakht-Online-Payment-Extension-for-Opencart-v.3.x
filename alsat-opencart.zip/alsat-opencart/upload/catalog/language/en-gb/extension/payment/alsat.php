<?php

$_['text_wait'] = 'Please Wait...';
$_['text_connect'] = 'Connecting To Alsat Pardakht...';
$_['text_order_no'] = 'خرید شماره: ';
$_['button_view_cart'] = 'View Shopping Cart';
$_['button_complete'] = 'Complete Payment';